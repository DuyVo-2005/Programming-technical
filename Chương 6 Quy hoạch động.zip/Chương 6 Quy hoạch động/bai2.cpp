/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
int permute(int n){
	if((n==0)||(n==1))
		return 1;
	else
		return permute(n-1)*n;
}
int combination(int n, int k){
	return permute(n)/(permute(n-k)*permute(k));
}
int main(int argc, char *argv[])
{
	int n, k;
	cin>>n>>k;
	cout<<combination(n,k);
	return 0;
}