/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
#define max 100
int n,W;
int F[max][max];//luu gia tien toi da
int x[max][max];//luu so luong duoc chon toi da
int main(int argc, char *argv[])
{
	cin>>n>>W;
	vector<int>a(n+1),c(n+1);
	for(int i=1;i<a.size();i++)
		cin>>a[i]>>c[i];
		
	int v, k;
	for(v=1;v<=W;v++){
		x[1][v]=v/a[1];
		F[1][v]=x[1][v]*c[1];
	}
	for(k=2;k<=n;k++)
		for(v=1;v<=W;v++){
			F[k][v]=F[k-1][v-0*a[k]]+0*c[k];
			for(int xk=1;xk<=v/a[k];xk++){				
				if(v-xk*a[k]>0&&F[k-1][v-xk*a[k]]+xk*c[k]>F[k][v]){
					F[k][v]=F[k-1][v-xk*a[k]]+xk*c[k];//cap nhat max F[k][v]
					x[k][v]=xk;
				}
			}
		}
	
	k=n, v=W;
	cout<<"Tong gia tri cac mon trong balo: "<<F[n][W]<<"\n";
	while(v>0&&k>0){
		if(F[k][v]>F[k-1][v]){
			cout<<"Chon "<<x[k][v]<<" mon loai "<<k<<", moi mon co khoi luong la "<<a[k]<<" va gia tri la "<<c[k]<<"\n";
			v=v-a[k]*x[k][W];
		}
		k--;
	}
	return 0;
}
/*
in:
5 13
3 4
4 5
5 6
2 3
1 1
out:
19
1 1
5 4
*/