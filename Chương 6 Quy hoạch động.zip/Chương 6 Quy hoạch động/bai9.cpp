/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#define max 100
#include<string.h>
#include<vector>
vector<pair<char,int> >v;//chu, tan so
void demSoLanKyTuXuatHienTrongChuoi(char tmp, char s[]){
	bool flag=false;//gia su ky tu chua xuat hien
	for(int i=0;i<v.size();i++)
		if(v[i].first==tmp){
			v[i].second++;
			flag=true;
		}
	if(flag==false)
		v.push_back({tmp,1});
}
void xuatKq(){
	for(int i=0;i<v.size();i++)
		cout<<v[i].first<<" "<<v[i].second<<"\n";
}
int main(int argc, char *argv[])
{
	char s[max];
	cin.getline(s,max);
	for(int i=0;i<strlen(s);i++)
		demSoLanKyTuXuatHienTrongChuoi(s[i],s);
	xuatKq();
	/*map<int,char>mp;
	string s="abcdef";
	for(int c:s)
		mp++;
	for(pair<int,char>x:mp)
		cout<<x.first<<" "<<x.second<<endl;*/
	return 0;
}