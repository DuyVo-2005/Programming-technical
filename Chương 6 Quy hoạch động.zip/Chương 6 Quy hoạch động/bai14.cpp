/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
int n, W;
int F[51][101];//chua cac chon toi uu voi chi so dong la chi so mon hang, chi so cot la trong luong toi da co the chua cua balo
bool choose[51];
int main(int argc, char *argv[])
{
	cin>>n>>W;
	vector<int>a(n+1);
	for(int i=1;i<=n;i++)
		cin>>a[i];
	
	int v,k;
	for(v=1;v<=W;v++){
		if(a[1]>v)
			F[1][v]=0;
		else
			F[1][v]=a[1];
	}//co so huy hoach dong
	
	for(k=2;k<=n;k++)
		for(v=1;v<=W;v++){
			if(a[k]>v)
				F[k][v]=F[k-1][v];
			else
				F[k][v]=max(F[k-1][v-a[k]]+a[k],F[k-1][v]);
		}
	
	cout<<F[n][W]<<"\n";//trong luong toi uu
	k=n, v=W;
	while(v>0&&k>0){
		if(F[k][v]>F[k-1][v]){
			choose[k]=true;
			v=F[k][v]-a[k];
		}
		k--;
	}
	
	for(int i=1;i<=n;i++)
		if(choose[i]==true)
			cout<<a[i]<<" ";
	return 0;
}
/*
in:
4 10
5 2 4 3
out:
10
5 2 3
*/
