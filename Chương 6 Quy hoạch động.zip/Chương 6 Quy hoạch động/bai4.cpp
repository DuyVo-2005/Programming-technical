/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
#define max 10000
vector<int>v;
int n;
bool mark[max];
void nhap(){
	for(int i=0;i<n;i++){
		int tmp;
		cin>>tmp;
		v.push_back(tmp);
	}
}
void xuat(){
	for(int i=0;i<v.size();i++)
		cout<<v[i]<<" ";
}
void xoaPhanTuTrung(){
	for(int i=0;i<v.size();i++)
		if(mark[v[i]]==true){
			v.erase(v.begin()+i);
			i--;//lùi lại để tránh xét thiếu
		}
		else
			mark[v[i]]=true;
}
int main(int argc, char *argv[])
{
	cin>>n;
	nhap();
	xoaPhanTuTrung();
	xuat();
	return 0;
}
/*7
1 2 3 2 1 2 4*/