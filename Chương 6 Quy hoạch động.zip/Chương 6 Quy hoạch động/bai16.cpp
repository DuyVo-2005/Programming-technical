/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
int n,W;
int F[51][101];
int main(int argc, char *argv[])
{
	cin>>n>>W;
	vector<int>a(n+1),C(n+1);
	for(int i=1;i<=n;i++){
		cin>>a[i]>>C[i];
	}
	
	int k,v;
	for(v=1;v<=W;v++){
		if(a[1]>v)
			F[1][v]=0;
		else
			F[1][v]=C[1];
	}//co so huy hoach dong
	
	for(k=2;k<=n;k++)
		for(v=1;v<=W;v++){
			if(a[k]>v){
				F[k][v]=F[k-1][v];
			}
			else{
				F[k][v]=max(F[k-1][v],F[k-1][v-a[k]]+C[k]);
			}
		}
	cout<<F[n][W]<<"\n";
	v=W, k=n;
	vector<bool>chosen(n+1,false);
	while(v>0&&k>0){
		if(F[k][v]>F[k-1][v]){
			chosen[k]=true;
			v=W-a[k];
		}
		k--;
	}
	for(int i=1;i<chosen.size();i++)
		if(chosen[i])
			cout<<a[i]<<" "<<C[i]<<"\n";
	return 0;
}
/*
in:
5 13
3 4
4 5
5 6
2 3
1 1
out:
16
3 4
4 5
5 6
1 1
*/