/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
#define max_W 1000
#include<algorithm>
int n;
int F[51][max_W];
int tong(vector<int>a){
	int sum=0;
	for(int i=0;i<a.size();i++)
		sum+=a[i];
	return sum;	
}
int main(int argc, char *argv[])
{
	cin>>n;
	vector<int>a(n+1);
	for(int i=1;i<=n;i++)
		cin>>a[i];
	int s=tong(a)/2;//tong so keo lon nhat ma em be 1 chon truoc
	
	int v, k;
	for(v=1;v<=s;v++)
	{
		if(a[1]>v)
			F[1][v]=0;
		else
			F[1][v]=a[1];
	}//co so huy hoach dong
	
	for(k=2;k<=n;k++){
		for(v=1;v<=s;v++)
			if(a[k]>v){
				F[k][v]=F[k-1][v];//khoi luong lon hon khoi luong chua toi da, ko chon, ko cap nhat
			}
			else{
				F[k][v]=max(F[k-1][v],F[k-1][v-a[k]]+a[k]);
			}
	}
	
	vector<bool>choose(n+1,false);
	v=s, k=n;
	while(v>0&&k>0){
		if(F[k][v]>F[k-1][v]){
			choose[k]=true;
			v=F[k][v]-a[k];
		}
		k--;
	}
	
	vector<int>beA, beB;	
	for(int i=1;i<=n;i++){
		if(choose[i])
			beA.push_back(a[i]);
		else
			beB.push_back(a[i]);
	}
	cout<<"Be thu nhat chon cac goi keo co so keo lan luot la: \n";
	for(int i=0;i<beA.size();i++)
		cout<<beA[i]<<" ";
	cout<<"\nTong so keo cua be thu nhat: "<<tong(beA);
	cout<<"\nBe thu hai chon cac goi keo co so keo lan luot la: \n";
	for(int i=0;i<beB.size();i++)
		cout<<beB[i]<<" ";
	cout<<"\nTong so keo cua be thu hai: "<<tong(beB);
	return 0;
}
/*
in:
5
1 2 3 4 5
out:
1 2 4
7
3 5
8

in:
6
1 2 3 3 2 1
out:

*/