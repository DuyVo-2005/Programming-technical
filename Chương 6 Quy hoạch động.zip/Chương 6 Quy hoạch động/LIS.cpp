//28tech
/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
void nhap(vector<float>&a){
	for(int i=0;i<a.size();i++)
		cin>>a[i];
}
int main(int argc, char *argv[])
{
	int n;
	cin>>n;
	vector<float>a(n);
	nhap(a);
	vector<int>L(n,1);
	for(int i=0;i<n;i++)
		for(int j=0;j<i;j++)
			if(a[i]>a[j])
				L[i]=max(L[i],L[j]+1);
	cout<<*max_element(L.begin(),L.end());
	return 0;
}
/*in: 8
1 2 3 6 5 9 11 8
out: 6*/