/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#define max 100
#include<vector>
vector<vector<int> >kq;
int n, a[max];
bool daXet[max];// danh dau vi tri mang da xet
void nhap(){
	for(int i=0;i<n;i++)
		cin>>a[i];
}
void xuatKq(){
	cout<<kq.size()<<endl;
	for(int i=0;i<kq.size();i++){
		for(int j=0;j<kq[i].size();j++)
			cout<<kq[i][j]<<" ";
		cout<<"\n";
	}
}
void demVaInMangConTang(int a[], int n){
	for(int i=0;i<n-1;i++){
		if(daXet[i]==false){
			vector<int>mangConTang;
			mangConTang.push_back(a[i]);
			daXet[i]=true;
			for(int j=i+1;j<n;j++)
				if(daXet[j]==false&&a[j]>a[j-1]){
					mangConTang.push_back(a[j]);
					daXet[j]=true;
				}
				else
					break;
			if(mangConTang.size()>1){
				kq.push_back(mangConTang);
			}
		}
	}
	xuatKq();
}
int main(int argc, char *argv[])
{
	cin>>n;
	nhap();
	demVaInMangConTang(a,n);
	return 0;
}
//in: 8 6 5 3 2 3 4 2 7
/*out: 2 3 4
			2 7
*/