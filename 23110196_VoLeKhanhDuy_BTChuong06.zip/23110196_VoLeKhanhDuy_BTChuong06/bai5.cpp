/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
//ma tran nhan duoc co dang n×m × m×p
#include<iostream>
using namespace std;
#define max 100
float a[max][max], b[max][max], c[max][max];
int row_a, col_a, row_b, col_b, row_c, col_c;
void nhap(float a[][max], int &row, int &col){
	cin>>row>>col;
	for(int i=0;i<row;i++)
		for(int j=0;j<col;j++)
			cin>>a[i][j];
}
float tichHangNhanCot(float a[max][max], int row_a, int col_a, float b[max][max], int row_b, int col_b, int i_row, int i_col){
	float kq=0;
	for(int i=0;i<col_a;i++)//hoac row_b
		kq+=a[i_row][i]*b[i][i_col];
	return kq;
}
void tich2MaTran(float a[][max], int row_a, int col_a, float b[][max], int row_b, int col_b, float c[][max], int row_c, int col_c){
	for(int i=0;i<row_c;i++)
		for(int j=0;j<col_c;j++)
			c[i][j]=tichHangNhanCot(a,row_a,col_a,b,row_b,col_b,i,j);	
}
void xuat(){
	for(int i=0;i<row_c;i++){
		for(int j=0;j<col_c;j++)
			cout<<c[i][j]<<" ";
		cout<<"\n";
	}
}
int main(int argc, char *argv[])
{
	bool flag=true;
	nhap(a,row_a,col_a);
	nhap(b,row_b,col_b);
	if(col_a==row_b){
		row_c=row_a;
		col_c=col_b;
		tich2MaTran(a,row_a,col_a,b,row_b,col_b,c,row_c,col_c);
	}
	else
		if(col_b==row_a)
		{
			col_c=col_a;
			row_c=row_b;
			tich2MaTran(b,row_b,col_b,a,row_a,col_a,c,row_c,col_c);
		}
		else
			flag=false;
	if(flag==false)
		cout<<"Hai ma tran vua nhap khong nhan duoc!";
	else{
		cout<<"Ket qua: \n";
		xuat();
	}
	return 0;
}
/*in:
2 2
1 2
3 4
2 2
0 1
0 0
(2 so m, n dau tien la kich thuoc ma tran thu nhat
m dong n cot tiep theo la cac phan tu cua ma tran thu nhat
2 so o, p tiep theo la kich thuoc ma tran thu hai
o dong p cot tiep theo la cac phan tu cua ma tran thu hai)
out: 
0 1
0 3
*/
/*in:
2 3
1 0 1
2 1 0
3 1
1
3
7
out:
8
5
*/
/*in:
3 1
1
3
7
2 3
1 0 1
2 1 0
out:
*/