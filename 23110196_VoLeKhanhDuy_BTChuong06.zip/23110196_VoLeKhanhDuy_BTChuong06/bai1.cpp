/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<vector>
vector<int>bin;
void xuat(){
	for(int i=bin.size()-1;i>=0;i--)
		cout<<bin[i];
	cout<<endl;
}
void chuyenSoSangNhiPhan(int n){
	bin.clear();
	while(n>0){
		bin.push_back(n%2);
		n/=2;
	}
	xuat();
}
int main(int argc, char *argv[])
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		chuyenSoSangNhiPhan(i);
		bin.clear();
	}
	return 0;
}