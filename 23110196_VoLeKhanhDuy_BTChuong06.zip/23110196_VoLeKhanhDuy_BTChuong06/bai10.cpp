/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#include<string.h>
#define max 100
void Strrev(char s[]){
	int begin=0, end=strlen(s)-1;
	while(begin<end){
		char tmp=s[begin];
		s[begin]=s[end];
		s[end]=tmp;
		begin++; end--;
	}
}
void daoTuTrongChuoi(char s[], char kq[]){
	char tmp[max];
	int i_tmp=0;
	for(int i=0;i<=strlen(s);i++){
		if(s[i]==' '||s[i]=='\0'){
			tmp[i_tmp]='\0';//ngat chuoi
			Strrev(tmp);	
			strcat(kq,tmp);
			strcat(kq," ");
			i_tmp=0;//khoi tao lai tmp[]
		}
		else
			tmp[i_tmp++]=s[i];
	}
	kq[strlen(kq)-1]='\0';// do du dau cach
}
int main(int argc, char *argv[])
{
	char s[max], kq[max];
	cin.getline(s,max);
	daoTuTrongChuoi(s,kq);
	cout<<kq;
	return 0;
}
//TU DO HANH PHUC
//A BC DE F