/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#define max 10000
double f[max];
void xuatNPhanTuDauTienDayFibonacci(int n){
	f[1]=1;
	f[2]=f[1];
	cout<<f[1]<<"\n"<<f[2];
	for(int i=3;i<=n;i++){
		f[i]=f[i-1]+f[i-2];
		cout<<"\n"<<f[i];
	}
}
int main(){
	int n;
	cin>>n;
	xuatNPhanTuDauTienDayFibonacci(n);
	return 0;
}
