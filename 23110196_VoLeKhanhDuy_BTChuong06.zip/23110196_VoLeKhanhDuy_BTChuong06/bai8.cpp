/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#define max 100
void taoTamGiacPascal(int a[][max], int n){
	for(int i=0;i<n;i++)
		for(int j=0;j<=i;j++)
			if(j==0||j==i)
				a[i][j]=1;
			else
				a[i][j]=a[i-1][j]+a[i-1][j-1];
}
void xuatTamGiacPascal(int a[][max], int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<=i;j++)
			cout<<a[i][j]<<" ";
		cout<<"\n";
	}
}
int main(int argc, char *argv[])
{
	int a[max][max], n;
	cout<<"Nhap so hang cua tam giac Pascal (so nguyen duong): ";
	cin>>n;
	taoTamGiacPascal(a,n);
	xuatTamGiacPascal(a,n);
	return 0;
}
/* in: 4
out: 
1
1 1
1 2 1
1 3 3 1*/