/* Ma so sinh vien: 23110196
 Ho va ten sinh vien: Vo Le Khanh Duy
 Ngay sinh:26/3/2005
 Lop:231101B-PRTE230385_23_2_04
*/
#include<iostream>
using namespace std;
#define max 100
#include<vector>
vector<float>kq;
int n;
float a[max], maxTong=0;
bool daXet[max];// danh dau vi tri mang da xet
void nhap(){
	for(int i=0;i<n;i++)
		cin>>a[i];
}
void xuatKq(){
	for(int i=0;i<kq.size();i++)
			cout<<kq[i]<<" ";
}
float tongMang(vector<float>a){
	float tong=0;
	for(int i=0;i<a.size();i++)
		tong+=a[i];
	return tong;
}
void inMangConTangTongLonNhat(float a[], int n){
	for(int i=0;i<n-1;i++){
		if(daXet[i]==false){
			vector<float>mangConTang;
			mangConTang.push_back(a[i]);
			daXet[i]=true;
			for(int j=i+1;j<n;j++)
				if(daXet[j]==false&&a[j]>a[j-1]){
					mangConTang.push_back(a[j]);
					daXet[j]=true;
				}
				else
					break;
			if(mangConTang.size()>1&&tongMang(mangConTang)>maxTong){
				maxTong=tongMang(mangConTang);
				kq.clear();
				kq=mangConTang;
			}
		}
	}
	xuatKq();
}
int main(int argc, char *argv[])
{
	cin>>n;
	nhap();
	inMangConTangTongLonNhat(a,n);
	return 0;
}
/*in: 9 6 5 3 2 3 4 2 7 8
out: 2 7 8
*/
/*in : 5 6 3 7 8 1
out: 7 8
*/